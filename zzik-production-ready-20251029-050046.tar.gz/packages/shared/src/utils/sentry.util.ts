// Sentry utility for easy error reporting across services
import * as Sentry from '@sentry/nextjs';

/**
 * Capture exception with context
 */
export function captureException(
  error: Error,
  context?: {
    userId?: string;
    tags?: Record<string, string>;
    extra?: Record<string, any>;
    level?: 'fatal' | 'error' | 'warning' | 'info' | 'debug';
  }
): string {
  if (!error) return '';

  Sentry.withScope((scope) => {
    // Set user context
    if (context?.userId) {
      scope.setUser({ id: context.userId });
    }

    // Set tags
    if (context?.tags) {
      Object.entries(context.tags).forEach(([key, value]) => {
        scope.setTag(key, value);
      });
    }

    // Set extra context
    if (context?.extra) {
      Object.entries(context.extra).forEach(([key, value]) => {
        scope.setExtra(key, value);
      });
    }

    // Set level
    if (context?.level) {
      scope.setLevel(context.level);
    }

    Sentry.captureException(error);
  });

  return error.message;
}

/**
 * Capture message (for non-error events)
 */
export function captureMessage(
  message: string,
  level: 'fatal' | 'error' | 'warning' | 'info' | 'debug' = 'info',
  context?: {
    userId?: string;
    tags?: Record<string, string>;
    extra?: Record<string, any>;
  }
): void {
  Sentry.withScope((scope) => {
    if (context?.userId) {
      scope.setUser({ id: context.userId });
    }

    if (context?.tags) {
      Object.entries(context.tags).forEach(([key, value]) => {
        scope.setTag(key, value);
      });
    }

    if (context?.extra) {
      Object.entries(context.extra).forEach(([key, value]) => {
        scope.setExtra(key, value);
      });
    }

    scope.setLevel(level);
    Sentry.captureMessage(message);
  });
}

/**
 * Start a transaction for performance monitoring
 */
export function startTransaction(
  name: string,
  op: string
): Sentry.Transaction | undefined {
  return Sentry.startTransaction({
    name,
    op,
  });
}

/**
 * Wrap async function with Sentry error capture
 */
export function withSentry<T extends (...args: any[]) => Promise<any>>(
  fn: T,
  options?: {
    name?: string;
    tags?: Record<string, string>;
  }
): T {
  return (async (...args: any[]) => {
    const transaction = options?.name
      ? Sentry.startTransaction({ name: options.name, op: 'function' })
      : undefined;

    try {
      const result = await fn(...args);
      transaction?.setStatus('ok');
      return result;
    } catch (error) {
      transaction?.setStatus('internal_error');
      
      captureException(error as Error, {
        tags: options?.tags,
        extra: {
          functionName: fn.name,
          arguments: args,
        },
      });
      
      throw error;
    } finally {
      transaction?.finish();
    }
  }) as T;
}

/**
 * Set user context globally
 */
export function setUser(user: {
  id: string;
  email?: string;
  username?: string;
  tier?: string;
}): void {
  Sentry.setUser(user);
}

/**
 * Clear user context
 */
export function clearUser(): void {
  Sentry.setUser(null);
}

/**
 * Add breadcrumb for debugging
 */
export function addBreadcrumb(
  message: string,
  category: string,
  level: 'fatal' | 'error' | 'warning' | 'info' | 'debug' = 'info',
  data?: Record<string, any>
): void {
  Sentry.addBreadcrumb({
    message,
    category,
    level,
    data,
    timestamp: Date.now() / 1000,
  });
}

/**
 * Helper for API route error handling
 */
export function handleAPIError(
  error: Error,
  context: {
    endpoint: string;
    method: string;
    userId?: string;
    params?: Record<string, any>;
  }
): void {
  captureException(error, {
    userId: context.userId,
    tags: {
      endpoint: context.endpoint,
      method: context.method,
    },
    extra: {
      params: context.params,
    },
    level: 'error',
  });
}

/**
 * Helper for service layer error handling
 */
export function handleServiceError(
  error: Error,
  context: {
    service: string;
    method: string;
    userId?: string;
    data?: Record<string, any>;
  }
): void {
  captureException(error, {
    userId: context.userId,
    tags: {
      service: context.service,
      method: context.method,
    },
    extra: {
      data: context.data,
    },
    level: 'error',
  });
}
