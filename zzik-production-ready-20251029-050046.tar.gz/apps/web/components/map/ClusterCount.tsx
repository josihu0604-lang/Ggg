export default function ClusterCount({ count }: { count: number }) {
  return <div className="cluster-pill liquid-glass-offer">{count}</div>;
}
