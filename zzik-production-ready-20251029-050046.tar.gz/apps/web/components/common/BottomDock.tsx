'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const items = [
  { href: '/feed', label: '홈' },
  { href: '/map', label: '지도' },
  { href: '/wallet', label: '지갑' },
  { href: '/profile', label: '프로필' },
];

export default function BottomDock() {
  const path = usePathname();

  return (
    <nav className="flex items-center justify-around">
      {items.map((it) => (
        <Link
          key={it.href}
          href={it.href}
          aria-current={path.startsWith(it.href) ? 'page' : undefined}
        >
          <button
            className="icon-btn"
            data-active={path.startsWith(it.href)}
          >
            {it.label}
          </button>
        </Link>
      ))}
    </nav>
  );
}
