// Sentry Edge Runtime Configuration
import * as Sentry from '@sentry/nextjs';

const SENTRY_DSN = process.env.SENTRY_DSN;
const SENTRY_ENVIRONMENT = process.env.SENTRY_ENVIRONMENT || 'development';

if (SENTRY_DSN) {
  Sentry.init({
    dsn: SENTRY_DSN,
    
    // Environment
    environment: SENTRY_ENVIRONMENT,
    
    // Release tracking
    release: process.env.SENTRY_RELEASE || 'zzik-v2@development',
    
    // Performance Monitoring (lower rate for edge)
    tracesSampleRate: SENTRY_ENVIRONMENT === 'production' ? 0.05 : 1.0,
    
    // Edge runtime has limitations
    beforeSend(event) {
      // Don't send errors in development
      if (SENTRY_ENVIRONMENT === 'development') {
        return null;
      }
      
      return event;
    },
  });
  
  console.log('[Sentry] Edge initialized', {
    environment: SENTRY_ENVIRONMENT,
  });
} else {
  console.warn('[Sentry] Edge not initialized: SENTRY_DSN not configured');
}
