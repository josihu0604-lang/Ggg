export default function WalletPage() {
  return (
    <div className="flex h-[100dvh] items-center justify-center p-4">
      <div className="liquid-glass-offer animate-liquid-appear rounded-2xl p-8 text-center">
        <h1 className="text-3xl font-bold">💰 지갑</h1>
        <p className="mt-4 text-sm opacity-80">
          포인트 잔액과 거래 내역을 확인하세요.
        </p>
        <div className="mt-6">
          <div className="text-5xl font-bold">0 PTS</div>
          <div className="mt-2 text-xs opacity-60">사용 가능한 포인트</div>
        </div>
      </div>
    </div>
  );
}
