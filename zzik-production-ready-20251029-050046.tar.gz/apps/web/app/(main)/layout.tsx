import '../globals.css';
import BottomDock from '../../components/common/BottomDock';

export const metadata = {
  title: 'ZZIK v2 - 찍먹',
  description: 'Location-based check-in rewards platform',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ko">
      <body className="bg-[oklch(0.15_0.004_280)] text-white">
        <main className="h-[100dvh]">{children}</main>
        <div className="fixed inset-x-0 bottom-0 pb-safe">
          <div className="liquid-glass-offer rounded-t-2xl p-2">
            <BottomDock />
          </div>
        </div>
      </body>
    </html>
  );
}
