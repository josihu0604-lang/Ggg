export default function FeedPage() {
  return (
    <div className="flex h-[100dvh] items-center justify-center p-4">
      <div className="liquid-glass-offer animate-liquid-appear rounded-2xl p-8 text-center">
        <h1 className="text-3xl font-bold">🏠 홈 피드</h1>
        <p className="mt-4 text-sm opacity-80">
          근처 오퍼와 체크인 활동이 표시됩니다.
        </p>
      </div>
    </div>
  );
}
