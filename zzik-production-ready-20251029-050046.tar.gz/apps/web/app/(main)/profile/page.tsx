export default function ProfilePage() {
  return (
    <div className="flex h-[100dvh] items-center justify-center p-4">
      <div className="liquid-glass-offer animate-liquid-appear rounded-2xl p-8 text-center">
        <h1 className="text-3xl font-bold">👤 프로필</h1>
        <p className="mt-4 text-sm opacity-80">
          내 정보와 활동 통계를 확인하세요.
        </p>
        <div className="mt-6 space-y-4">
          <div className="rounded-xl bg-white/5 p-4">
            <div className="text-xs opacity-60">총 체크인</div>
            <div className="text-2xl font-bold">0회</div>
          </div>
          <div className="rounded-xl bg-white/5 p-4">
            <div className="text-xs opacity-60">가입일</div>
            <div className="text-sm">2025년 10월</div>
          </div>
        </div>
      </div>
    </div>
  );
}
