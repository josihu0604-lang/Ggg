'use client';

import dynamic from 'next/dynamic';

const InteractiveMap = dynamic(
  () => import('../../components/map/InteractiveMap'),
  { ssr: false }
);

export default function MapPage() {
  return (
    <div className="h-[100dvh]">
      <InteractiveMap />
    </div>
  );
}
