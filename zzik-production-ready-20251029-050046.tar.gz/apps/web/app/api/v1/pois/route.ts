import { NextRequest, NextResponse } from 'next/server';
import { getCached } from '@zzik/shared/src/utils/cache.util';
import { prisma } from '@zzik/database/src/client';
import { z } from 'zod';

const QuerySchema = z.object({
  lat: z.coerce.number().min(-90).max(90),
  lng: z.coerce.number().min(-180).max(180),
  radius: z.coerce.number().min(50).max(5000).default(2000),
});

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);

  const parsed = QuerySchema.safeParse({
    lat: searchParams.get('lat'),
    lng: searchParams.get('lng'),
    radius: searchParams.get('radius') ?? undefined,
  });

  if (!parsed.success) {
    return NextResponse.json({ error: 'invalid_query' }, { status: 400 });
  }

  const { lat, lng, radius } = parsed.data;
  const key = `pois:${lat.toFixed(5)}:${lng.toFixed(5)}:${radius}`;

  const features = await getCached(
    key,
    async () => {
      // Using PostgreSQL earthdistance for geo queries
      const rows = await prisma.$queryRawUnsafe<any[]>(
        `
        SELECT id, name, category, lat, lng, thumbnail_url, visit_count,
               earth_distance(ll_to_earth($1,$2), ll_to_earth(lat,lng)) AS distance,
               2000 + (random()*4000)::int AS reward
        FROM "POI"
        WHERE status='active'
          AND earth_box(ll_to_earth($1,$2), $3) @> ll_to_earth(lat,lng)
        ORDER BY distance
        LIMIT 100
      `,
        lat,
        lng,
        radius
      );

      return rows.map((r) => ({
        type: 'Feature',
        geometry: { type: 'Point', coordinates: [r.lng, r.lat] },
        properties: {
          id: r.id,
          name: r.name,
          category: r.category,
          distance: r.distance,
          reward: r.reward,
          thumbnail: r.thumbnail_url,
        },
      }));
    },
    60 // Cache for 60 seconds
  );

  return NextResponse.json({
    type: 'FeatureCollection',
    features,
  });
}
