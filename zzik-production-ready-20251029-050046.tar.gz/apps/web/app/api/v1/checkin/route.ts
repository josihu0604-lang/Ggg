import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { CheckinService } from '@zzik/shared/src/services/checkin.service';
import { SettlementService } from '@zzik/shared/src/services/settlement.service';
import { AppError, handleAPIError } from '@zzik/shared/src/utils/error.util';
import { getCached, setCache } from '@zzik/shared/src/utils/cache.util';

const BodySchema = z.object({
  poiId: z.string().min(8),
  location: z.object({
    lat: z.number(),
    lng: z.number(),
    accuracy: z.number().positive(),
  }),
  deviceInfo: z.any().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const idem = req.headers.get('Idempotency-Key') || '';
    const userId = req.headers.get('x-user-id') || 'demo-user'; // Demo/pilot guard

    const body = BodySchema.parse(await req.json());

    // Idempotency: return same response for 120s
    if (idem) {
      const cached = await getCached<any>(
        `idem:${userId}:${idem}`,
        async () => null,
        120
      );
      if (cached) {
        return NextResponse.json(cached, { status: 200 });
      }
    }

    // Validate and create check-in
    const { valid, reason, details, checkinId } =
      await CheckinService.validateAndCreate({
        userId,
        ...body,
        ipAddress: req.ip || undefined,
      });

    if (!valid || !checkinId) {
      throw new AppError('CHECKIN_INVALID', reason || 'invalid', 400, details);
    }

    // Settle CPCV
    const settlement = await SettlementService.settleCPCV(checkinId);

    const result = {
      success: true,
      check_in_id: checkinId,
      reward_pts: settlement.userReward,
      message: `체크인 완료! +${settlement.userReward} PTS`,
    };

    // Cache idempotency result for 120s
    if (idem) {
      await setCache(`idem:${userId}:${idem}`, result, 120);
    }

    return NextResponse.json(result, { status: 201 });
  } catch (e) {
    return handleAPIError(e);
  }
}
