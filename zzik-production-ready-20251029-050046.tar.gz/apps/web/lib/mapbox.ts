export const MAPBOX_TOKEN = process.env.NEXT_PUBLIC_MAPBOX_TOKEN!;
export const MAP_STYLE = 'mapbox://styles/mapbox/navigation-night-v1';
